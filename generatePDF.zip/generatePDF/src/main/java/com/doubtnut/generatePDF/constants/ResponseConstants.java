package com.doubtnut.generatePDF.constants;

public class ResponseConstants {

	public static String success = "Success";

	public static String error = "Error";

}
